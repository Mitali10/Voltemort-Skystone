package org.firstinspires.ftc.teamcode;

import com.qualcomm.robotcore.eventloop.opmode.Autonomous;
import com.qualcomm.robotcore.eventloop.opmode.Disabled;

import org.firstinspires.ftc.robotcore.external.tfod.Recognition;

import java.util.List;

import static java.lang.Math.abs;


@Autonomous(name = "SkystoneAutoRed", group = "Skystone")
//@Disabled
public class SkystoneAutoRed extends SkystoneAutonomousBase {

    @Override
    public void runOpMode() {

        setupAllHardware();

        int pos = -1;
        int d = 0; //36;

        foundationServo1.setPosition(1.0);  // horiz pos
        foundationServo2.setPosition(1.0);  // horiz pos
        turnServo.setPosition(ARM_UP);
        gripperServo.setPosition(GRIPPER_OPEN_POS);

        nextTask = Task.APPROACH_STONES;

        telemetry.addData("Hardware setup, ready to play", "");
        telemetry.update();

        waitForStart();
        runtime.reset();


        while (opModeIsActive()) {


            switch (nextTask) {

                case APPROACH_STONES:
                    encoderDrive(0.4, 23, 10);
                    encoderStrafeLeft(0.4, 5, 6);

                    nextTask = Task.SEARCH;
                    break;


                case SEARCH:
                    if(checkRecognitions(0.8)) {
                        pos = 1;    // farthest from skybridge
                        d = 16;
                        nextTask = Task.LIFT_SKYSTONE;
                        break;
                    }

                    encoderStrafeRight(0.3, 9, 10);

                    if(checkRecognitions(0.8)) {
                        pos = 2;
                        d = 8;
                        nextTask = Task.LIFT_SKYSTONE;
                        break;
                    }

                    pos = 3;    // closest to skybridge
                    encoderStrafeRight(0.3, 8, 10);

                    nextTask = Task.LIFT_SKYSTONE;

                    break;


                case LIFT_SKYSTONE:
                    encoderDriveForwardUntilDistance(0.2, 10.5, 2.5);

                    turnServo.setPosition(ARM_DOWN);

                    sleep(400);

                    gripperServo.setPosition(GRIPPER_CLOSE_POS);

                    sleep(400);

                    turnServo.setPosition(ARM_UP);

                    sleep(400);

                    nextTask = Task.DRIVE_TO_FOUNDATION;
                    break;

                case DRIVE_TO_FOUNDATION:

                    foundationServo1.setPosition(0.6);  // horiz pos
                    foundationServo2.setPosition(0.55);  // horiz pos

                    encoderDrive(0.3, -3, 10);

                    encoderStrafeRight(0.6, 47 + d + 15, 20);

                    turnToZero();

                    turnServo.setPosition(ARM_UP + 0.15);

                    encoderDrive(0.5, 7, 5);

                    nextTask = Task.DROP_SKYSTONE;
                    break;

                case DROP_SKYSTONE:

                    gripperServo.setPosition(GRIPPER_OPEN_POS);

                    sleep(400);

                    gripperServo.setPosition(GRIPPER_CLOSE_POS);

                    nextTask = Task.RETURN_TO_STONES;

                    break;

                case RETURN_TO_STONES:

                    encoderDrive(0.5, -8, 5);

                    foundationServo1.setPosition(1.0);  // horiz pos
                    foundationServo2.setPosition(1.0);  // horiz pos

                    if(pos == 1) {
                        d = -24;
                    }

                    encoderStrafeLeft(0.6, 48 + d + 24 + 15, 10);

                    gripperServo.setPosition(GRIPPER_OPEN_POS);

                    turnToZero();

                    if(pos == 1) {
                        encoderDriveForwardUntilDistance(0.2, 12, 2.5);
                    } else {
                        encoderDriveForwardUntilDistance(0.2, 10.5, 2.5);
                    }


                    nextTask = Task.LIFT_SKYSTONE2;
                    break;

                case LIFT_SKYSTONE2:

                    turnServo.setPosition(ARM_DOWN);

                    sleep(400);

                    gripperServo.setPosition(GRIPPER_CLOSE_POS);

                    sleep(400);

                    turnServo.setPosition(ARM_UP);

                    sleep(400);

                    nextTask = Task.DROP_SKYSTONE2;
                    break;

                case DROP_SKYSTONE2:

                    encoderDrive(0.4, -4, 10);

                    foundationServo1.setPosition(0.6);  // horiz pos
                    foundationServo2.setPosition(0.55);  // horiz pos

                    encoderStrafeRight(0.6, 48 + d + 24 + 24, 20);

                    turnServo.setPosition(ARM_UP + 0.15);

                    encoderDrive(0.5, 11, 10);

                    nextTask = Task.MOVE_FOUNDATION;
                    break;


                case MOVE_FOUNDATION:

                    turnToZero();

                    encoderDriveForwardUntilDistance(0.2, 7.4, 2);

                    gripperServo.setPosition(GRIPPER_OPEN_POS);

                    foundationServo1.setPosition(1.0);
                    foundationServo2.setPosition(1.0);

                    sleep(500);

                    encoderDrive(0.6, -35, 10);

                    gripperServo.setPosition(GRIPPER_CLOSE_POS);

                    turnRight(90);

                    turnTo90Right();

                    foundationServo1.setPosition(0.6);  // horiz pos
                    foundationServo2.setPosition(0.55);  // horiz pos
                    sleep(300);

                    nextTask = Task.PARK;
                    break;

                case PARK:
                    turnServo.setPosition(0.0);
                    encoderStrafeLeft(0.6, 15, 10);
                    encoderDrive(0.6, -35, 10);
                    nextTask = Task.HALT;
                    break;


                case HALT:

                    break;



            }


        }

    }



}



